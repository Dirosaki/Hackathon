package br.com.superapp.mvp.model.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.superapp.mvp.model.entity.Telemedicina;

public interface TelemedicinaDAO extends CrudRepository<Telemedicina, Long>{

}
